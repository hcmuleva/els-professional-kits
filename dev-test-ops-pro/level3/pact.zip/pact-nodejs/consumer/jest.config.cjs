// jest.config.cjs
module.exports = {
  transform: {
    "^.+\\.jsx?$": "babel-jest"
  }
};
